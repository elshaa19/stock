export const getMaterials = () => {
  return JSON.parse(localStorage.getItem('materials')) || [];
};

export const addMaterial = (material) => {
  const materials = getMaterials();
  materials.unshift(material);
  localStorage.setItem('materials', JSON.stringify(materials));
};